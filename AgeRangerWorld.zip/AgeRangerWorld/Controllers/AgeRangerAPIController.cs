﻿using AgeRangerWorld.BLL;
using AgeRangerWorld.Models;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.Net;
using System.Web.Http;

namespace AgeRangerWorld.Controllers
{
    public class AgeRangerAPIController : ApiController
    {
        /// <summary>
        /// retrieve all persons
        /// </summary>
        /// <returns>list of persons</returns>
        [Route("api/AgeRangerAPI"), HttpGet]
        public IEnumerable<Person> Get()
        {
            try
            {
                return new PersonManagement().GetAllPersons();

            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Retrieve person by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>person</returns>
        // GET: api/AgeRangerAPI/5
        public Person Get(int id)
        {
            try
            {
                Person p = new PersonManagement().GetPerson(id);
                if (p == null)
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                return p;
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Search persons using firstname or lastname or using both, empty first namd and last name will retrieve all persons
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <returns>list of matching persons</returns>
        [Route("api/AgeRangerAPI/Search"), HttpGet]
        public IEnumerable<Person> Get([FromUri]string firstName = "", [FromUri]string lastName = "")
        {
            try
            {
                return new PersonManagement().Search(firstName, lastName);
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Add new person by given inputs
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="age"></param>
        /// <returns>httpresponse OK result</returns>
        // POST: api/AgeRangerAPI
        public IHttpActionResult Post([FromBody]string firstName, [FromBody]string lastName, [FromBody]int age)
        {
            try
            {
                int result = new PersonManagement().AddPerson(firstName, lastName, age);
                if (result == 0)
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                return Ok();
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }

        }

        /// <summary>
        /// Edit person by id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="age"></param>
        /// <returns>httpresponse OK result</returns>
        // PUT: api/AgeRangerAPI/5
        public IHttpActionResult Put(int id, [FromBody]string firstName, [FromBody]string lastName, [FromBody]int age)
        {
            try
            {
                int result = new PersonManagement().UpdatePerson(id, firstName, lastName, age);
                if (result == 0)
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                return Ok();
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Delete person by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>httpresponse OK result</returns>
        // DELETE: api/AgeRangerAPI/5
        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            try
            {
                int result = new PersonManagement().DeletePerson(id);
                if (result == 0)
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                return Ok();
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }
    }
}
