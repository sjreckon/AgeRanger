﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Results;
using System.Web.Mvc;
using AgeRangerWorld.Models;
using System.Data.SQLite;
using System.Web.Http;

namespace AgeRangerWorld.Controllers
{
    public class AgeRangerController : Controller
    {
        // GET: AgeRanger
        AgeRangerAPIController _apiController = new AgeRangerAPIController();

        /// <summary>
        /// Default action loads all controls with list of persons partial view if available
        /// </summary>
        /// <returns>default view</returns>
        public ActionResult Index()
        {
            IEnumerable<Person> persons;
            persons = _apiController.Get();
            return View(persons);
        }

        /// <summary>
        /// Action error loads error view when there is an application error
        /// </summary>
        /// <returns>view with eror message</returns>
        public ActionResult Error()
        {
            return View();
        }

        /// <summary>
        /// Action loads a view for new persons
        /// </summary>
        /// <returns>view with controls for adding new person </returns>
        public ActionResult AddPerson()
        {
            return PartialView("_AddPerson");
        }


        /// <summary>
        /// Action loads the person data in edit view
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Edit view</returns>
        public ActionResult GetPerson(int id)
        {
            Person person = _apiController.Get(id);
            return PartialView("_EditPerson", person);
        }

        /// <summary>
        /// Action searches the person data for given input
        /// </summary>
        /// <param name="id"></param>
        /// <returns>list of persons view</returns>
        public ActionResult SearchPersons(string firstName, string lastName)
        {
            IEnumerable<Person> persons;
            persons = _apiController.Get(firstName, lastName);
            return PartialView("_ViewPersons", persons);
        }

        /// <summary>
        /// Action submits new person data
        /// </summary>
        /// <param name="id"></param>
        /// <returns>refreshed persons view</returns>
        public ActionResult AddPersonData(Person person)
        {
            IHttpActionResult result = _apiController.Post(person.FirstName, person.LastName, person.Age);
            IEnumerable<Person> persons;
            persons = _apiController.Get();
            return PartialView("_ViewPersons", persons);
        }

        /// <summary>
        /// Action to perform deletion for given id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>refreshed persons view</returns>
        public ActionResult DeletePerson(int id)
        {
            IHttpActionResult result = _apiController.Delete(id);
            IEnumerable<Person> persons;
            persons = _apiController.Get();
            return PartialView("_ViewPersons", persons);
        }

        /// <summary>
        /// Action to submit edited data
        /// </summary>
        /// <param name="id"></param>
        /// <returns>refreshed persons view</returns>
        public ActionResult EditPerson(Person p)
        {
            IHttpActionResult result = _apiController.Put(p.Id, p.FirstName, p.LastName, p.Age);
            IEnumerable<Person> persons;
            persons = _apiController.Get();
            return PartialView("_ViewPersons", persons);
        }
    }
}