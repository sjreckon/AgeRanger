﻿using AgeRangerWorld.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.Linq;
using System.Web;

namespace AgeRangerWorld.DAL
{
    /// <summary>
    /// Data access layer which is injected with interface which is passed from business layer
    /// </summary>
    public class PersonDataAccess
    {
        private IDal _idal;
        public PersonDataAccess(IDal dal)
        {
            _idal = dal;
        }
        public IEnumerable<Person> GetAllPersons()
        {
            return _idal.GetAllPersons().ToList();
        }

        public Person GetPerson(int id)
        {
            return _idal.GetPerson(id);
        }

        public IEnumerable<Person> Search(string firstName, string lastName)
        {
            return _idal.Search(firstName, lastName);
        }

        public int AddPerson(string firstName, string lastName, int age)
        {
            return _idal.AddPerson(firstName, lastName, age);
        }

        public int UpdatePerson(int id, string firstName, string lastName, int age)
        {
            return _idal.UpdatePerson(id, firstName, lastName, age);
        }

        public int DeletePerson(int id)
        {
            return _idal.DeletePerson(id);
        }
    }

    public interface IDal
    {
        IEnumerable<Person> GetAllPersons();

        Person GetPerson(int id);
        IEnumerable<Person> Search(string firstName, string lastName);

        int AddPerson(string firstName, string lastName, int age);

        int UpdatePerson(int id, string firstName, string lastName, int age);

        int DeletePerson(int id);
    }

    public class SQLiteData : IDal
    {
        readonly string _dataSource;
        public SQLiteData()
        {
            //Read data source from config
            _dataSource = ConfigurationManager.AppSettings["SQLiteSource"];
        }
        public int AddPerson(string firstName, string lastName, int age)
        {
            int result = 0;
            Person p = new Person { Age = age, FirstName = firstName, LastName = lastName };

            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {
                connection.Open();
                SQLiteCommand cmd =
                    new SQLiteCommand(
                        string.Format("insert into Person (firstname, lastname, age) values ('{0}','{1}',{2})", firstName,
                            lastName, age), connection);
                result = cmd.ExecuteNonQuery();
                return result;
            }
        }

        public int DeletePerson(int id)
        {
            int result = 0;
            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {
                connection.Open();
                SQLiteCommand cmd = new SQLiteCommand(string.Format("delete from Person where id={0}", id), connection);
                result = cmd.ExecuteNonQuery();
                return result;
            }
        }

        public IEnumerable<Person> GetAllPersons()
        {
            List<Person> persons = new List<Person>();
            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {
                //The max int is pulled from config to compare maxage with highest range
                connection.Open();
                SQLiteCommand cmd = new SQLiteCommand("select p.*,"+ getAgeGroupCommand() + " from Person p ", connection);
                SQLiteDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Person p = new Person
                    {
                        Id = int.Parse(rdr["id"].ToString()),
                        Age = int.Parse(rdr["age"].ToString()),
                        FirstName = rdr["firstname"].ToString(),
                        LastName = rdr["lastname"].ToString(),
                        AgeGroup = rdr["agegroupdesc"].ToString()

                    };
                    persons.Add(p);
                }
            }
            return persons;
        }

        public Person GetPerson(int id)
        {
            Person person = null;
            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {
                connection.Open();
                SQLiteCommand cmd = new SQLiteCommand(string.Format("Select * from Person where id={0}", id), connection);
                SQLiteDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    person = new Person
                    {
                        Id = int.Parse(rdr["id"].ToString()),
                        Age = int.Parse(rdr["age"].ToString()),
                        FirstName = rdr["firstname"].ToString(),
                        LastName = rdr["lastname"].ToString()
                    };
                }
            }
            return person;
        }

        string getAgeGroupCommand()
        {
            string ageGroupCommand = @"(select ag.description from (select 
case when minage is null or minage = '' then 0 else minage end as minage,
case when maxage is null then " + ConfigurationManager.AppSettings["MaxInt"] + @" else maxage end as maxage,
description
from agegroup
) ag where p.age >= ag.minage and p.age < ag.maxage) as agegroupdesc";
            return ageGroupCommand;
        }
        public IEnumerable<Person> Search(string firstName, string lastName)
        {
            List<Person> persons = new List<Person>();

            

            string whereCondition = string.IsNullOrEmpty(firstName)
                    ? (string.IsNullOrEmpty(lastName) ? string.Empty : "lastname like '%" + lastName + "%'")
                    : "firstname like '%" + firstName + "%' " +
                      (string.IsNullOrEmpty(lastName) ? string.Empty : " and lastname like '%" + lastName + "%'");

            string cmdText = "Select p.*," + getAgeGroupCommand() + " from Person p " + (whereCondition == string.Empty ? string.Empty : "where " + whereCondition);

            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {
                connection.Open();
                SQLiteCommand cmd = new SQLiteCommand(cmdText, connection);
                SQLiteDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Person p = new Person
                    {
                        Id = int.Parse(rdr["id"].ToString()),
                        Age = int.Parse(rdr["age"].ToString()),
                        FirstName = rdr["firstname"].ToString(),
                        LastName = rdr["lastname"].ToString(),
                        AgeGroup = rdr["agegroupdesc"].ToString()
                    };
                    persons.Add(p);
                }
            }
            return persons;
        }

        public int UpdatePerson(int id, string firstName, string lastName, int age)
        {
            int result = 0;
            using (SQLiteConnection connection = new SQLiteConnection(_dataSource))
            {

                connection.Open();
                SQLiteCommand cmd =
                    new SQLiteCommand(
                        string.Format("update person set firstname='{0}', lastname='{1}', age={2} where id={3}", firstName, lastName, age, id), connection);
                result = cmd.ExecuteNonQuery();
                return result;
            }
        }
    }
}