﻿using AgeRangerWorld.DAL;
using AgeRangerWorld.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AgeRangerWorld.BLL
{
    /// <summary>
    /// Business class to talk to DAL and retrive data. Any additional rules can be applied in BLL if required
    /// It is injected with right dependency based on the datasource
    /// </summary>
    public class PersonManagement
    {
        public IEnumerable<Person> GetAllPersons()
        {
            return new PersonDataAccess(new SQLiteData()).GetAllPersons();
        }

        public Person GetPerson(int id)
        {
            return new PersonDataAccess(new SQLiteData()).GetPerson(id);
        }

        public IEnumerable<Person> Search(string firstName, string lastName)
        {
            return new PersonDataAccess(new SQLiteData()).Search(firstName, lastName);
        }

        public int AddPerson(string firstName, string lastName, int age)
        {
            return new PersonDataAccess(new SQLiteData()).AddPerson(firstName, lastName, age);
        }

        public int UpdatePerson(int id, string firstName, string lastName, int age)
        {
            return new PersonDataAccess(new SQLiteData()).UpdatePerson(id,firstName, lastName, age);
        }

        public int DeletePerson(int id)
        {
            return new PersonDataAccess(new SQLiteData()).DeletePerson(id);
        }
    }
}