﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AgeRangerWorld.Controllers;
using AgeRangerWorld.Models;
using System.Web.Http;
using System.Net;
using System.Web.Http.Results;
using System.Collections.Generic;
using System.Linq;
namespace AgeRangerWorld.Tests
{
    [TestClass]
    public class AgeRangerTests
    {
        [TestMethod]
        public void TestPersonGet()
        {
            try
            {
                AgeRangerAPIController controller = new AgeRangerAPIController();
                IEnumerable<Person> persons = controller.Get();
                Assert.AreEqual(12, persons.Count());
            }
            catch (HttpResponseException ex)
            {
                Assert.AreEqual(ex.Response.StatusCode,
                    HttpStatusCode.BadRequest,
                    "Wrong response type");
                throw;
            }
        }

        [TestMethod]
        public void TestPersonGetPerson()
        {
            try
            {
                AgeRangerAPIController controller = new AgeRangerAPIController();
                var response = controller.Get(21);
                Assert.AreEqual("jack", response.FirstName);
            }
            catch (HttpResponseException ex)
            {
                Assert.AreEqual(ex.Response.StatusCode,
                    HttpStatusCode.BadRequest,
                    "Wrong response type");
                throw;
            }
        }

        [TestMethod]
        public void TestPersonAdd()
        {
            try
            {
                AgeRangerAPIController controller = new AgeRangerAPIController();
                IHttpActionResult response = controller.Post("firstname3", "lastname3", 33);
                Assert.IsInstanceOfType(response, typeof(OkResult));
            }
            catch (HttpResponseException ex)
            {
                Assert.AreEqual(ex.Response.StatusCode,
                    HttpStatusCode.BadRequest,
                    "Wrong response type");
                throw;
            }
        }

        [TestMethod]
        public void TestPersonEdit()
        {
            try
            {
                AgeRangerAPIController controller = new AgeRangerAPIController();
                IHttpActionResult response = controller.Put(37,"firstname2", "lastname2", 22);
                Assert.IsInstanceOfType(response, typeof(OkResult));
            }
            catch (HttpResponseException ex)
            {
                Assert.AreEqual(ex.Response.StatusCode,
                    HttpStatusCode.BadRequest,
                    "Wrong response type");
                throw;
            }
        }

        [TestMethod]
        public void TestPersonDelete()
        {
            try
            {
                AgeRangerAPIController controller = new AgeRangerAPIController();
                IHttpActionResult response = controller.Delete(37);
                Assert.IsInstanceOfType(response, typeof(OkResult));
            }
            catch (HttpResponseException ex)
            {
                Assert.AreEqual(ex.Response.StatusCode,
                    HttpStatusCode.BadRequest,
                    "Wrong response type");
                throw;
            }
        }
    }
}
